# Data Parser

The REST API service to parse the data

List of supported API's 

Version 1
 - POST - parse
Version 2
 - POST - parse

```
npm install
```
### Run the Application

The project is preconfigured with a simple development web server. The simplest way to start this server is:
````
npm start
```
Navigte to .env file to configure the application global configuration